import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {HttpClient} from "@angular/common/http";

/**
 * Generated class for the SignupfinalPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
    selector: 'page-signupfinal',
    templateUrl: 'signupfinal.html',
})
export class SignupfinalPage {
    private signUpFinalForm:FormGroup;
    private selectOptions;
    private formdataval = this.navParams.data;
    private genrelist:any;
    private statelist:any;
    public arrayGenre2=[];
    public typeVal=[];
    public arrayGenre1=[];

    constructor(public navCtrl: NavController, public navParams: NavParams,private formBuild:FormBuilder, private http:HttpClient) {
        console.log('this.formdataval');
        console.log(this.formdataval);

        this.selectOptions=                             //select options
        {
            title:'Gender',
            selectedText:'Select your Gender:'



        };
        this.signUpFinalForm = formBuild.group({

            realname:['',Validators.required],
            alias:['',Validators.required],
            gender:[''],
            genre:[''],
            experience:['',Validators.required],
            website:['',Validators.required],
            bio:['',Validators.required],
            hometown:['',Validators.required],
            address:['',Validators.required],
            zip:['',Validators.required],
            beginner:[false],
            Elementary:[false],
            junior:[false],
            senior:[false],
            maori:[false],
            fstnation:[false],
            native:[false],
            indOther:[false],
            pacific:[false],
            other:[false],
            aus:[false],
            state:[''],

        })
        console.log(this.typeVal);
    }

    genreFunc(){
        console.log('this.formdataval');
        console.log(this.formdataval);

        if(this.formdataval.musicians == true){

            this.typeVal.push('Musician');
            console.log('musician');


        }
        if(this.formdataval.dancer == true){

            this.typeVal.push('Dancer');
            console.log('dancer');


        }
        if(this.formdataval.model == true){

            this.typeVal.push('Model');
            console.log('model');


        }
        if(this.formdataval.signupaffiliate == true){

            this.typeVal.push('Affiliate');
            console.log('signupaffiliate');


        }
        if(this.formdataval.fan == true){

            this.typeVal.push('Fan');
            console.log('fan');


        }

        for(let j in   this.typeVal){

            for (let i in this.genrelist) {

                for (let k in this.genrelist[i].type) {

                    if(this.typeVal[j]=='Musician' && this.genrelist[i].type[k] ==  'Musician'){

                        console.log('this.genrelist[i].type[k]');
                        console.log(this.genrelist[i].type[k]);
                        //     this.genrelist.filter(function (item) {
                        //
                        //     var x= this.arrayGenre2.findIndex(p =>p.genrename  == item.genrename);
                        //     if(x <= -1){
                        //         this.arrayGenre2.push({_id: item._id, genrename: item.genrename});
                        //     }
                        //     return null;
                        // });
                        // console.log('this.arrayGenre2');
                        // console.log(this.arrayGenre2);
                        console.log('indexof');
                        console.log(this.arrayGenre2.indexOf(this.genrelist[i]));
                        if(this.arrayGenre2.indexOf(this.genrelist[i])== -1)
                            this.arrayGenre2.push(this.genrelist[i]);
                    }
                    if(this.typeVal[j]=='Dancer' && this.genrelist[i].type[k] ==  'Dancer'){
                        if(this.arrayGenre1.indexOf(this.genrelist[i])== -1)
                            this.arrayGenre1.push(this.genrelist[i]);
                    }
                }
            }
        }


        //filter with common values
        console.log(this.arrayGenre2);
        console.log(this.arrayGenre1);

    }
    signupfinal(){
        console.log('this.formdataval');
        console.log(this.formdataval);
        this.signUpFinalForm.markAsPristine();
        for(let i in this.signUpFinalForm.controls){
            this.signUpFinalForm.controls[i].markAsTouched();
            console.log('this.signUpFinalForm.value');
            console.log(this.signUpFinalForm.value);
            console.log(this.signUpFinalForm.controls[i].valid);
        }
        if (this.signUpFinalForm.valid){
            var link = 'https://audiodeadline.com/server1.php?q=signup2';
            var formdataval2 = this.signUpFinalForm.value;
            formdataval2._id =this.formdataval._id;
            // formdataval2.type=[];
            //
            // if(this.formdataval.musicians == true){
            //
            //     this.typeVal.push('Musician');
            //     console.log('musician');
            //
            //
            // }
            // if(this.formdataval.dancer == true){
            //
            //     this.typeVal.push('Dancer');
            //     console.log('dancer');
            //
            //
            // }
            // if(this.formdataval.model == true){
            //
            //     this.typeVal.push('Model');
            //     console.log('model');
            //
            //
            // }
            // if(this.formdataval.signupaffiliate == true){
            //
            //     this.typeVal.push('Affiliate');
            //     console.log('signupaffiliate');
            //
            //
            // }
            // if(this.formdataval.fan == true){
            //
            //     this.typeVal.push('Fan');
            //     console.log('fan');
            //
            //
            // }



            if (formdataval2.Elementary == true){

                formdataval2.ability = 'Elementary';
            }
            if (formdataval2.beginner == true){

                formdataval2.ability = 'beginner';
            }
            if (formdataval2.junior == true){

                formdataval2.ability = 'junior';
            }
            if (formdataval2.senior == true){

                formdataval2.ability = 'senior';
            }
            if (formdataval2.maori == true){

                formdataval2.ethinicity = 'Indigenous Maori';
            }
            if (formdataval2.fstnation == true){

                formdataval2.ethinicity = 'Indigenous First Nations';
            }
            if (formdataval2.native == true){

                formdataval2.ethinicity = 'Indigenous Native American';
            }
            if (formdataval2.indOther == true){

                formdataval2.ethinicity = 'Indigenous Other';
            }
            if (formdataval2.pacific == true){

                formdataval2.ethinicity = 'Indigenous Pacific Nations';
            }
            if (formdataval2.other == true){

                formdataval2.ethinicity = 'Other Ethinicity';
            }
            if (formdataval2.aus == true){

                formdataval2.ethinicity = 'Indigenous Aboriginal - Aus';
            }
            console.log( this.typeVal);
            // for(let j in   this.typeVal){
            //     for (let i in this.genrelist) {
            //         for (let k in this.genrelist[i].type) {
            //
            //
            //             console.log('typeval');
            //
            //             console.log('this.genrelist[i].type[k]');
            //             console.log(this.genrelist[i].type[k]);
            //             console.log('typeVal[j]');
            //             console.log( this.typeVal[j]);
            //             if (this.genrelist[i].type[k] ==  'musicians') {
            //
            //                 this.arrayGenre.push(this.genrelist[i]);
            //                 console.log('this.arrayGenre[0].type');
            //                 console.log(this.arrayGenre[0].type);
            //
            //             }
            //             if (this.genrelist[i].type[k] ==  'dancer') {
            //
            //                 this.arrayGenre1.push(this.genrelist[i]);
            //
            //
            //             }
            //
            //             //   if(jQuery.inArray("test", myarray) !== -1)
            //         }
            //     }
            // }



            //   if(jQuery.inArray("test", myarray) !== -1)



            console.log( this.typeVal);

            formdataval2.type=  this.typeVal;
            console.log('formdataval2.type');
            console.log(formdataval2.type);
            this.http.post(link, formdataval2)
                .subscribe(data =>{
                        let dataForm:any ='';
                        console.log(dataForm);
                        dataForm=data;
                        console.log(dataForm.status);
                        if (dataForm.status == 'success'){

                            console.log('success');

                            console.log('this.formdataval2');
                            console.log(formdataval2);

                        }

                        if (dataForm.status=='error'){
                            console.log('error');

                        }

                    },error =>{

                        console.log('error..........');
                    }


                );
        }
    }
    ngOnInit() {

        console.log('oninit');
        const link2='https://audiodeadline.com/server1.php?q=getusastates';
        this.http.get(link2)
            .subscribe(data => {
                let data1:any ='';
                console.log(data1);
                data1=data;


                console.log('data1');
                console.log(data1);
                // console.log('data1.res');
                // console.log(data1.res);
                this.statelist= data1;
                // console.log(data1.status);
                // // data received by server
                // console.log(data1.headers);

            },error => {

                console.log(error.status);
                console.log(error.error); // error message as string
                console.log(error.headers);

            });
        const link3='https://audiodeadline.com/server1.php?q=genrelist';
        this.http.get(link3)
            .subscribe(data => {
                let data2:any ='';
                console.log(data2);
                data2=data;
                console.log('data2');
                this.genrelist= data2.res;
                console.log(data2.res);
                // console.log(data2.status);
                // // data received by server
                // console.log(data2.headers);

                this.genreFunc();
            },error => {

                console.log(error.status);
                console.log(error.error);                 // error message as string
                console.log(error.headers);

            });

    }
    singleChoice() {
        if (this.signUpFinalForm.value.Elementary == true) {

            this.signUpFinalForm.patchValue({

                beginner: false,
                junior: false,
                senior: false
            });

        }
        if(this.signUpFinalForm.value.beginner == true ){

            this.signUpFinalForm.patchValue({

                Elementary: false,
                junior: false,
                senior: false
                }
            );

        }
        if(this.signUpFinalForm.value.junior == true ){

            this.signUpFinalForm.patchValue({

                Elementary: false,
                beginner: false,
                senior: false
                }
            );

        }
        if(this.signUpFinalForm.value.senior == true ){

            this.signUpFinalForm.patchValue({

                Elementary: false,
                beginner: false,
                junior: false
                }
            );

        }

    }

    singleChoiceEthinicity(){

        if (this.signUpFinalForm.value.maori == true) {

            this.signUpFinalForm.patchValue({

                fstnation: false,
                native: false,
                indOther: false,
                pacific: false,
                other: false,
                aus: false
            });

        }
        if (this.signUpFinalForm.value.fstnation == true) {

            this.signUpFinalForm.patchValue({

                maori: false,
                native: false,
                indOther: false,
                pacific: false,
                other: false,
                aus: false
            });

        }
        if (this.signUpFinalForm.value.native == true) {

            this.signUpFinalForm.patchValue({

                maori: false,
                fstnation: false,
                indOther: false,
                pacific: false,
                other: false,
                aus: false
            });

        }
        if (this.signUpFinalForm.value.indOther == true) {

            this.signUpFinalForm.patchValue({

                maori: false,
                fstnation: false,
                native: false,
                pacific: false,
                other: false,
                aus: false
            });

        }
        if (this.signUpFinalForm.value.pacific == true) {

            this.signUpFinalForm.patchValue({

                maori: false,
                fstnation: false,
                native: false,
                indOther: false,
                other: false,
                aus: false
            });

        }
        if (this.signUpFinalForm.value.other == true) {

            this.signUpFinalForm.patchValue({

                maori: false,
                fstnation: false,
                native: false,
                indOther: false,
                pacific: false,
                aus: false
            });

        }
        if (this.signUpFinalForm.value.aus == true) {

            this.signUpFinalForm.patchValue({

                maori: false,
                fstnation: false,
                native: false,
                indOther: false,
                pacific: false,
                other: false
            });

        }

    }

    ionViewDidLoad() {
        console.log('ionViewDidLoad SignupfinalPage');
    }

}
