import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import {FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl,} from '@angular/forms';
import {HttpClient} from "@angular/common/http";
import {HomePage} from "../home/home";
import { AlertController } from 'ionic-angular';
import {SignupfinalPage} from "../signupfinal/signupfinal"

/**
 * Generated class for the SignupDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-signup-detail',
  templateUrl: 'signup-detail.html',
})
export class SignupDetailPage {
  private signUpDetailForm: FormGroup;
  private homepage:any;
  // public errormsgforlogin:any='';
  private selectOptions;
  private signupfinalpage;

  constructor(public navCtrl: NavController, public navParams: NavParams, private formBuild: FormBuilder, public _http:HttpClient, public alertCtrl:AlertController) {
    this.signupfinalpage=SignupfinalPage;
    this.selectOptions=                             //select options
    {
      title:'Gender',
      selectedText:'Select your Gender:'



    };
    this.signUpDetailForm = formBuild.group({

      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      gender: [''],
      email: ['', Validators.compose([Validators.required, Validators.pattern(/^\s*[\w\-\+_]+(\.[\w\-\+_]+)*\@[\w\-\+_]+\.[\w\-\+_]+(\.[\w\-\+_]+)*\s*$/)])],
      username:['',Validators.required],
      password:['',Validators.compose([Validators.required,Validators.minLength(6), Validators.maxLength(15)])],
      confirmPassword:['',Validators.compose([Validators.required,Validators.minLength(6), Validators.maxLength(15),
        this.equalToPass('password')
      ])],
      phone: ['',Validators.required ],

        // Validators.compose([Validators.required,Validators.pattern(/^[0-9]{10}$/)])

      terms: [false,Validators.requiredTrue],
    });

  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad SignupDetailPage');
  }

  equalToPass(fieldname): ValidatorFn {                                 //password match custom function
    return (control: AbstractControl): { [key: string]: any } => {
      let input = control.value;
      console.log('control.value');
      console.log(control.value);
      console.log(control.root.value[fieldname]);
      let isValid = control.root.value[fieldname] == input;
      console.log('isValid');
      console.log(isValid);

      if (!isValid)
        return{
          equalTo:true            //this value will be called
        };

    };

  }
  // // static customValidator(inputEmail)
  // // {
  // //   console.log('inputEmail');
  // //   console.log(inputEmail);
  // //
  // //
  // //   if (inputEmail.pristine) {
  // //     return null;
  // //   }
  // //
  // //
  // //   inputEmail.markAsTouched();
  // //   if(inputEmail.value==''  || inputEmail.value==null){
  // //     console.log('inputEmail blank');
  // //     return {
  // //       invalidEmail: true
  // //     };
  // //   }
  //
  //   let filter = /^\s*[\w\-\+_]+(\.[\w\-\+_]+)*\@[\w\-\+_]+\.[\w\-\+_]+(\.[\w\-\+_]+)*\s*$/;
  //   console.log(String(inputEmail.value).search(filter) != -1);
  //   if (String(inputEmail.value).search(filter) == -1) {
  //     console.log('valid');
  //     return {
  //       invalidEmail: true
  //     };
  //   }
  // }
  signUpDetails() {
    this.signUpDetailForm.markAsPristine();     // triggering validation in this function

    for(let i in this.signUpDetailForm.controls){
      this.signUpDetailForm.controls[i].markAsTouched();
      console.log(this.signUpDetailForm.value);
      console.log(this.signUpDetailForm.controls[i].valid);
    }
    console.log('this.signUpDetailForm.valid');
    console.log(this.signUpDetailForm.valid);
    if (this.signUpDetailForm.valid){
      var link = 'https://audiodeadline.com/server1.php?q=signup';
      var formdataval = this.signUpDetailForm.value;
      formdataval=Object.assign(formdataval,this.navParams.data);     //merge two objects in formdataval
      formdataval.mediaid='';
      formdataval.parent='';
      console.log(formdataval);

      this._http.post(link, formdataval)

          .subscribe(data => {

            let dataval:any='';

            console.log(data);      //value


            dataval=data;
            console.log(dataval.status);     //status
            if(dataval.status=='error'){      //if info error
              console.log('error');
              const alert = this.alertCtrl.create({

                title:'Error!',
                subTitle:dataval.msg,
                buttons:['OK']

              });
              alert.present();

            }
            if(dataval.status=='success'){                      //if  succeeded


              console.log('success');

               this.navCtrl.push(this.signupfinalpage, formdataval );
              console.log(formdataval);
            }

          }, error => {
            console.log("Oooops!");
          })  ;
    }

  }

}





